package main;

public class CovidAntiBodyTest extends CovidTest implements Exportable {
    
    private String bloodSampleId;
    public CovidAntiBodyTest(String bloodSampleId) {
        this.bloodSampleId = bloodSampleId;

    }
     public String getBloodSampleId() {
        return this.bloodSampleId;
     }

     @Override
     public String getSampleId(){
        return bloodSampleId;
     }
     public String export() {
        return "null, " + bloodSampleId;
     }

}
