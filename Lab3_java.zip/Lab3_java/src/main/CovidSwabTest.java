package main;

public class CovidSwabTest extends CovidTest implements Exportable {
    private String swabId;
    public CovidSwabTest(String swabId){
        this.swabId = swabId;

    }
   public String getSampleId(){
        return this.swabId;
    }
    public String export() {
        if (getResult() == null) {
            return "null, " + swabId;
        } else {
            return getResult() + ", " + swabId;
        }
    }
}
