package main;

public interface Exportable {
    String export();
}
