package main;

public enum Result {
    inconclusive, positive, negative
}
