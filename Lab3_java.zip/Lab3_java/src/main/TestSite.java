package main;



import java.util.ArrayList;

public class TestSite implements Exportable {
    private ArrayList<CovidTest> tests;

    public void addTest(CovidTest t){
        if (tests == null){
            tests = new ArrayList<>();
        }
        tests.add(t);
    }
    public void runTests(){
        for (CovidTest test : tests){
            test.setResult(Laboratory.doTest(test.getSampleId()));
        }

    }
    public String export(){
        if (tests == null){
            return "";
        }

       String output = "";
        for (CovidTest test : tests) {
            output = output + (test.export() + "\n");
        }
        return output;

    }
}
